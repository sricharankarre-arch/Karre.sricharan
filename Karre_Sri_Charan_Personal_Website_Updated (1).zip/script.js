document.getElementById('year').textContent=new Date().getFullYear();
const b=document.getElementById('menu'),n=document.getElementById('nav');
b.addEventListener('click',()=>n.classList.toggle('open'));
n.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>n.classList.remove('open')));
