Karre Sri Charan — Personal Portfolio

Open index.html to preview the website. Upload all files in this folder to GitHub Pages, Netlify or Vercel for a public site.

Name: Karre Sri Charan
Location: Warangal, Telangana, India
Degree: B.Tech AI & Data Science, B.V. Raju Institute of Technology (2026–2030)
Email: sricharankarre@gmail.com
Phone: +91 91779 58305
LinkedIn: https://www.linkedin.com/in/karresricharan
